#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


//============================================PROTOTIP FUNKCIJA============================================//

struct igrac {
	char ime[30];
	int poeni;
};


void pocetak();
void rezultat();
void instrukcije();
void rangLista(char ime[], int poeni);

main()
{
	do {
		fflush(stdin);
		system("cls");
		printf("\n\n\n\t\tDobrodosli u igru pogadjanja najduze reci od ponudjenih slova (slucajno razmestenih na pocetku) \n\n");
		printf("\t\tAutor Stefan Stankovic NRT 46/15\n\n\n\n");

		printf("\t\t1. Za pocetak igre unesite slovo p\n\n");
		printf("\t\t2. Za rezultate unesite slovo r\n\n");
		printf("\t\t3. Za instrukcije unesite slovo k\n\n");
		printf("\t\t4. Za izlaz iz igre unesite slovo i\n\n");



		char izbor;

		scanf("%c", &izbor);
		getchar();

		if (izbor == 'p')				//pocetak igre
		{

			pocetak();
		}

		else if (izbor == 'r')			//rezultati
		{
			rezultat();
		}

		else if (izbor == 'k')			//instrukcije
		{
			instrukcije();
		}

		else if (izbor == 'i')			//izlaz
		{
			printf("\nDovidjenja.\n\n");
			exit(0);
		}

		else
		{
			printf("\n\nNiste uneli dobar karakter.\n\n");		//pogresan unos
			system("pause");
			system("cls");
		}

	} while (1);
	return 0;
}

//============================================FUNKCIJA ZA POCETAK IGRE==============================//

//============================================PRVI NIVO============================================//

void pocetak()
{
	system("cls");
	while (1) {
		FILE *fptr;			//pokazivac na datoteku
		char niz[] = { 'S','O','C','I','J','A','L','I','S','T','A','N','J' };
		char rec1[20];
		char rec2[20];
		char opcija;
		int kontrola = 0;



		int a, b, i, pom, duzina, poeni1, poeni2, poeni3, poeni4, poeni5;			//promenljive
		srand(time(NULL));
		struct igrac player;

		for (i = 0; i < 12; i++) {				//rand funkcija za mesanje slova
			a = rand() % 12;
			b = rand() % 12;
			pom = niz[a];
			niz[a] = niz[b];
			niz[b] = pom;
		}

		printf("\t\n\n\tDobrodosli u prvi nivo\n");
		printf("\n\tUnesite vase ime : ");
		gets(player.ime);
		printf("\n\tPonudjena slova : \n");
		printf("\n\t");
		for (i = 0; i < 13; i++)

		{
			printf("%c ", niz[i]);
		}

		printf("\n\n\t");

		fptr = fopen("datoteka.txt", "r");		//provera
		if (fptr == NULL)
		{
			printf("greska");
			exit(1);
		}
		fflush(stdin);
		printf("Vasa rec : ");

		scanf("%s", rec1);
		getchar();
		duzina = strlen(rec1);
		poeni1 = duzina * 2;
		if (poeni1 == 22)
		{
			poeni1 = poeni1 + 5;
		}

		while (!feof(fptr))			//radi sve dok ne dodje do kraja datoteke
		{
			fscanf(fptr, "%s", rec2);
			if (strcmp(rec2, rec1) == 0)
			{
				printf("\n\tVasa najduza rec je %s i ona ima %d slova, osvojili ste %d poena \n\n\t", rec2, duzina, poeni1);
				kontrola = 1;
				break;
			}

		}
		if (kontrola == 0) {
			printf("\n\n\tUneta rec ne postoji u datoteci\n\n");
			poeni1 = 0;

		}
		kontrola = 0;

		printf("\n\tDa li zelite u drugi nivo ? \n\n");
		printf("\tUnesite d ili D za nastavak ili bilo koji karakter za izlaz\n");
		fflush(stdin);
		opcija = getchar();
		opcija = toupper(opcija);
		if (opcija != 'D') {
			printf("\n\n\tIzabrali ste da izadjete!\n");
			break;
		}




		//============================================DRUGI NIVO============================================//


		system("cls");
		char niz1[] = { 'F','I','L','O','Z','O','F','S','K','I','B','G' };

		srand(time(NULL));

		for (i = 0; i < 11; i++) {
			a = rand() % 12;
			b = rand() % 12;
			pom = niz1[a];
			niz1[a] = niz1[b];
			niz1[b] = pom;
		}

		printf("\n\n\tDobrodosli u drugi nivo\n");
		printf("\n\tPonudjena slova : \n");
		printf("\n\t");
		for (i = 0; i < 12; i++)

		{
			printf("%c ", niz1[i]);
		}

		printf("\n\n\t");

		fptr = fopen("datoteka.txt", "r");
		if (fptr == NULL)
		{
			printf("greska");
			exit(1);
		}

		printf("Vasa rec : ");

		scanf("%s", rec1);
		duzina = strlen(rec1);
		poeni2 = duzina * 2;

		if (poeni2 == 20)
		{
			poeni2 = poeni2 + 5;
		}

		while (!feof(fptr))
		{
			fscanf(fptr, "%s", rec2);
			if (strcmp(rec2, rec1) == 0)
			{
				printf("\n\tVasa najduza rec je %s i ona ima %d slova, osvojili ste %d poena za sada\n\n\t", rec2, duzina, poeni1 + poeni2);
				kontrola = 1;
				break;
			}
		}

		if (kontrola == 0) {
			printf("\n\n\tUneta rec ne postoji u datoteci\n\n");
			poeni2 = 0;
		}
		kontrola = 0;

		printf("\n\tDa li zelite u treci nivo ? \n\n");
		printf("\tUnesite d ili D za nastavak ili bilo koji karakter za izlaz\n");
		fflush(stdin);
		getchar();
		opcija = getchar();
		opcija = toupper(opcija);
		if (opcija != 'D') {
			printf("\n\n\tIzabrali ste da izadjete!\n");
			break;
		}




		//============================================TRECI NIVO============================================//


		system("cls");
		char niz2[] = { 'P','E','D','A','G','O','G','I','J','A','Z','L','J' };

		srand(time(NULL));

		for (i = 0; i < 13; i++) {
			a = rand() % 13;
			b = rand() % 13;
			pom = niz2[a];
			niz2[a] = niz2[b];
			niz2[b] = pom;
		}

		printf("\n\n\tDobrodosli u treci nivo\n");
		printf("\n\tPonudjena slova : \n");
		printf("\n\t");
		for (i = 0; i < 13; i++)

		{
			printf("%c ", niz2[i]);
		}

		printf("\n\n\t");

		fptr = fopen("datoteka.txt", "r");
		if (fptr == NULL)
		{
			printf("greska");
			exit(1);
		}

		printf("Vasa rec : ");

		scanf("%s", rec1);
		duzina = strlen(rec1);
		poeni3 = duzina * 2;

		if (poeni3 == 20)
		{
			poeni3 = poeni3 + 5;
		}

		while (!feof(fptr))
		{
			fscanf(fptr, "%s", rec2);
			if (strcmp(rec2, rec1) == 0)
			{
				printf("\n\tVasa najduza rec je %s i ona ima %d slova, osvojili ste %d poena za sada\n\n\t", rec2, duzina, poeni1 + poeni2 + poeni3);
				kontrola = 1;
				break;
			}
		}


		if (kontrola == 0) {
			printf("\n\n\tUneta rec ne postoji u datoteci\n\n");
			poeni3 = 0;
		}
		kontrola = 0;

		printf("\n\tDa li zelite u cetvrti nivo ? \n\n");
		printf("\tUnesite d ili D za nastavak ili bilo koji karakter za izlaz\n");
		fflush(stdin);
		getchar();
		opcija = getchar();
		opcija = toupper(opcija);
		if (opcija != 'D') {
			printf("\n\n\tIzabrali ste da izadjete!\n");
			break;
		}


		//============================================CETVRTI NIVO============================================//



		system("cls");
		char niz3[] = { 'S','I','N','U','S','O','I','D','N','I','P','E' };

		srand(time(NULL));

		for (i = 0; i < 12; i++) {
			a = rand() % 12;
			b = rand() % 12;
			pom = niz3[a];
			niz3[a] = niz3[b];
			niz3[b] = pom;
		}

		printf("\n\n\tDobrodosli u cetvrti nivo\n");
		printf("\n\tPonudjena slova : \n");
		printf("\n\t");
		for (i = 0; i < 12; i++)

		{
			printf("%c ", niz3[i]);
		}

		printf("\n\n\t");

		fptr = fopen("datoteka.txt", "r");
		if (fptr == NULL)
		{
			printf("greska");
			exit(1);
		}

		printf("Vasa rec : ");

		scanf("%s", rec1);
		duzina = strlen(rec1);
		poeni4 = duzina * 2;

		if (poeni4 == 20)
		{
			poeni4 = poeni4 + 5;
		}

		while (!feof(fptr))
		{
			fscanf(fptr, "%s", rec2);
			if (strcmp(rec2, rec1) == 0)
			{
				printf("\n\tVasa najduza rec je %s i ona ima %d slova, osvojili ste %d poena za sada\n\n\t", rec2, duzina, poeni1 + poeni2 + poeni3 + poeni4);
				kontrola = 1;
				break;
			}
		}


		if (kontrola == 0) {
			printf("\n\n\tUneta rec ne postoji u datoteci\n\n");
			poeni4 = 0;
		}
		kontrola = 0;


		printf("\n\tDa li zelite u peti nivo ? \n\n");
		printf("\tUnesite d ili D za nastavak ili bilo koji karakter za izlaz\n");
		fflush(stdin);
		getchar();
		opcija = getchar();
		opcija = toupper(opcija);
		if (opcija != 'D') {
			printf("\n\n\tIzabrali ste da izadjete!\n");
			break;
		}


		//============================================PETI NIVO============================================//



		system("cls");
		char niz4[] = { 'D','E','V','E','L','O','P','E','R','S','K','E' };

		srand(time(NULL));

		for (i = 0; i < 12; i++) {
			a = rand() % 12;
			b = rand() % 12;
			pom = niz4[a];
			niz4[a] = niz4[b];
			niz4[b] = pom;
		}

		printf("\n\n\tDobrodosli u peti nivo\n");
		printf("\n\tPonudjena slova : \n");
		printf("\n\t");
		for (i = 0; i < 12; i++)

		{
			printf("%c ", niz4[i]);
		}

		printf("\n\n\t");

		fptr = fopen("datoteka.txt", "r");
		if (fptr == NULL)
		{
			printf("greska");
			exit(1);
		}

		printf("Vasa rec : ");

		scanf("%s", rec1);
		duzina = strlen(rec1);
		poeni5 = duzina * 2;

		if (poeni5 == 24)
		{
			poeni5 = poeni5 + 5;
		}

		while (!feof(fptr))
		{
			fscanf(fptr, "%s", rec2);
			if (strcmp(rec2, rec1) == 0)
			{
				printf("\n\tVasa najduza rec je %s i ona ima %d slova, osvojili ste ukupno %d poena\n\n\t", rec2, duzina, poeni1 + poeni2 + poeni3 + poeni4 + poeni5);
				kontrola = 1;
				break;
			}
		}

		if (kontrola == 0) {
			printf("\n\n\tUneta rec ne postoji u datoteci\n\n");
			poeni5 = 0;
		}
		kontrola = 0;

		player.poeni = poeni1 + poeni2 + poeni3 + poeni4 + poeni5;

		rangLista(player.ime, player.poeni);


		printf("\n\n\t\tZavrsili ste sa igranjem igrice :) \n");
		break;



	}
	fflush(stdin);
	system("pause");
}


//============================================FUNKCIJA ZA REZULTAT==================================//


void rezultat()
{
	system("cls");
	struct igrac pom;
	FILE *f;
	int i;

	if ((f = fopen("c:\\Users\\spear\\Desktop\\ConsoleApplication1\\ConsoleApplication1\\rang_lista.bin", "rb")) == NULL) //HTELO JE JEDINO OVAKO
	{
		printf("Greska");
		getchar();
		exit(1);
	}
	printf("\n\n\t\tRANG LISTA");
	for (i = 0; i < 5; i++) {
		fread(&pom, sizeof(struct igrac), 1, f);
		printf("\n\n\t\t%s\t%d", pom.ime, pom.poeni);

	}

	printf("\n\n");

	fclose(f);

	system("pause");


}


//============================================FUNKCIJA ZA INSTRUKCIJE================================//

void instrukcije()
{
	system("cls");
	printf("Igra ima 5 nivoa i vas zadatak je da pronadjete najduzu rec od ponudjenih slova koja su \nnamerno izmesana da bi vama bilo teze. Ako vezete niz od pogodjenih reci poeni se sabiraju.\n\n");
	printf("Za povratak u glavni meni pritisnite bilo sta.\n\n");
	system("pause");
}


//============================================FUNKCIJA ZA RANG LISTU================================//


void rangLista(char ime[], int poeni) {
	struct igrac *player, pom;
	FILE *ptr;
	int i, j;

	if ((player = malloc(6 * sizeof(struct igrac))) == NULL) {
		printf("\nGreska\n");
		exit(1);
	}
	if ((ptr = fopen("rang_lista.bin", "rb")) == NULL) {
		printf("Greska");
		exit(1);
	}
	for (i = 0; i < 5; i++) {
		fread(&pom, sizeof(struct igrac), 1, ptr);
		strcpy(player[i].ime, pom.ime);
		player[i].poeni = pom.poeni;
	}
	fclose(ptr);
	strcpy(player[5].ime, ime);
	player[5].poeni = poeni;

	for (i = 0; i < 5; i++)
		for (j = i + 1; j < 6; j++)
			if (player[i].poeni < player[j].poeni) {
				pom = player[i];
				player[i] = player[j];
				player[j] = pom;
			}
	ptr = fopen("rang_lista.bin", "wb");
	fwrite(player, sizeof(struct igrac), 5, ptr);
	fclose(ptr);

	free(player);

}
